package com.example.llama

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadata
import com.arm.aichat.gguf.GgufMetadataReader
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {

    // Android views
    private lateinit var ggufTv: TextView
    private lateinit var messagesRv: RecyclerView
    private lateinit var userInputEt: EditText
    private lateinit var userActionFab: FloatingActionButton

    // Arm AI Chat inference engine
    private lateinit var engine: InferenceEngine
    private var generationJob: Job? = null

    // Conversation states
    private var isModelReady = false
    private var currentModelName: String = "unknown"
    private val messages = mutableListOf<Message>()
    private val lastAssistantMsg = StringBuilder()
    private val messageAdapter = MessageAdapter(messages)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        // View model boilerplate and state management is out of this basic sample's scope
        onBackPressedDispatcher.addCallback { Log.w(TAG, "Ignore back press for simplicity") }

        // PHASE 0: establish what device/RAM class we're actually running on
        // before anything else happens, so later numbers have context.
        Log.i(TAG, "PHASE0 device: ${DeviceTelemetry.deviceSummary(applicationContext)}")
        Log.i(TAG, "PHASE0 " + DeviceTelemetry.snapshot(applicationContext, "baseline, before model load"))

        // Find views
        ggufTv = findViewById(R.id.gguf)
        messagesRv = findViewById(R.id.messages)
        messagesRv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        messagesRv.adapter = messageAdapter
        userInputEt = findViewById(R.id.user_input)
        userActionFab = findViewById(R.id.fab)

        // Arm AI Chat initialization
        lifecycleScope.launch(Dispatchers.Default) {
            engine = AiChat.getInferenceEngine(applicationContext)
        }

        // Upon CTA button tapped: pick + load a model, or send a chat message
        userActionFab.setOnClickListener {
            if (isModelReady) {
                // If model is ready, validate input and send to engine
                handleUserInput()
            } else {
                // Otherwise, prompt user to select a GGUF metadata on the device
                getContent.launch(arrayOf("*/*"))
            }
        }

        // PHASE 0: long-press the FAB to run the standardized pp/tg benchmark
        // once a model is loaded. Kept separate from the send action so it
        // never fires by accident mid-chat.
        userActionFab.setOnLongClickListener {
            if (isModelReady) {
                lifecycleScope.launch(Dispatchers.Default) { runBenchmark() }
            } else {
                Toast.makeText(
                    this,
                    "Load a model first, then long-press to benchmark",
                    Toast.LENGTH_SHORT
                ).show()
            }
            true
        }
    }

    private val getContent = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        Log.i(TAG, "Selected file uri:\n $uri")
        uri?.let { handleSelectedModel(it) }
    }

    /**
     * Handles the file Uri from [getContent] result
     */
    private fun handleSelectedModel(uri: Uri) {
        // Update UI states
        userActionFab.isEnabled = false
        userInputEt.hint = "Parsing GGUF..."
        ggufTv.text = "Parsing metadata from selected file \n$uri"

        lifecycleScope.launch(Dispatchers.IO) {
            // Parse GGUF metadata
            Log.i(TAG, "Parsing GGUF metadata...")
            contentResolver.openInputStream(uri)?.use {
                GgufMetadataReader.create().readStructuredMetadata(it)
            }?.let { metadata ->
                // Update UI to show GGUF metadata to user
                Log.i(TAG, "GGUF parsed: \n$metadata")
                withContext(Dispatchers.Main) {
                    ggufTv.text = metadata.toString()
                }

                // Ensure the model file is available
                val modelName = metadata.filename() + FILE_EXTENSION_GGUF
                currentModelName = modelName
                contentResolver.openInputStream(uri)?.use { input ->
                    ensureModelFile(modelName, input)
                }?.let { modelFile ->
                    val loadStartMs = System.currentTimeMillis()
                    loadModel(modelName, modelFile)
                    val loadMs = System.currentTimeMillis() - loadStartMs
                    Log.i(TAG, "PHASE0 model load took ${loadMs}ms")
                    val postLoadSnapshot = DeviceTelemetry.snapshot(applicationContext, "after model load")
                    Log.i(TAG, "PHASE0 $postLoadSnapshot")

                    withContext(Dispatchers.Main) {
                        isModelReady = true
                        userInputEt.hint = "Type and send a message!"
                        userInputEt.isEnabled = true
                        userActionFab.setImageResource(R.drawable.outline_send_24)
                        userActionFab.isEnabled = true
                        messages.add(
                            Message(
                                UUID.randomUUID().toString(),
                                "Model loaded in ${loadMs}ms.\n$postLoadSnapshot",
                                false
                            )
                        )
                        messageAdapter.notifyItemInserted(messages.size - 1)
                    }
                }
            }
        }
    }

    /**
     * Prepare the model file within app's private storage
     */
    private suspend fun ensureModelFile(modelName: String, input: InputStream) =
        withContext(Dispatchers.IO) {
            File(ensureModelsDirectory(), modelName).also { file ->
                // Copy the file into local storage if not yet done
                if (!file.exists()) {
                    Log.i(TAG, "Start copying file to $modelName")
                    withContext(Dispatchers.Main) {
                        userInputEt.hint = "Copying file..."
                    }

                    FileOutputStream(file).use { input.copyTo(it) }
                    Log.i(TAG, "Finished copying file to $modelName")
                } else {
                    Log.i(TAG, "File already exists $modelName")
                }
            }
        }

    /**
     * Load the model file from the app private storage
     */
    private suspend fun loadModel(modelName: String, modelFile: File) =
        withContext(Dispatchers.IO) {
            Log.i(TAG, "Loading model $modelName")
            withContext(Dispatchers.Main) {
                userInputEt.hint = "Loading model..."
            }
            engine.loadModel(modelFile.path)
        }

    /**
     * Validate and send the user message into [InferenceEngine]
     */
    private fun handleUserInput() {
        userInputEt.text.toString().also { userMsg ->
            if (userMsg.isEmpty()) {
                Toast.makeText(this, "Input message is empty!", Toast.LENGTH_SHORT).show()
            } else {
                userInputEt.text = null
                userInputEt.isEnabled = false
                userActionFab.isEnabled = false

                // Update message states
                messages.add(Message(UUID.randomUUID().toString(), userMsg, true))
                lastAssistantMsg.clear()
                messages.add(Message(UUID.randomUUID().toString(), lastAssistantMsg.toString(), false))

                // PHASE 0: real end-to-end timing, separate from the synthetic
                // bench() numbers below -- this is what a student actually
                // experiences while waiting for a reply. Token count is an
                // approximation (one Flow emission per generateNextToken()
                // call, which corresponds closely but not perfectly to model
                // tokens for multi-byte UTF-8 pieces) -- fine for Phase 0's
                // "is this workable at all" question, not meant as a precise
                // benchmark; that's what runBenchmark() is for.
                val genStartNs = System.nanoTime()
                var firstTokenNs = -1L
                var tokenCount = 0

                generationJob = lifecycleScope.launch(Dispatchers.Default) {
                    engine.sendUserPrompt(userMsg)
                        .onCompletion {
                            val totalMs = (System.nanoTime() - genStartNs) / 1_000_000.0
                            val ttftMs = if (firstTokenNs > 0)
                                (firstTokenNs - genStartNs) / 1_000_000.0 else -1.0
                            val decodeMs = if (firstTokenNs > 0)
                                (System.nanoTime() - firstTokenNs) / 1_000_000.0 else -1.0
                            val tokPerSec = if (decodeMs > 0) tokenCount / (decodeMs / 1000.0) else -1.0
                            val summary = "PHASE0 real-chat timing -- " +
                                    "time-to-first-token: ${"%.0f".format(ttftMs)}ms, " +
                                    "decode: ${"%.2f".format(tokPerSec)} tok/s over $tokenCount tokens, " +
                                    "total: ${"%.0f".format(totalMs)}ms"
                            Log.i(TAG, summary)
                            Log.i(TAG, "PHASE0 " + DeviceTelemetry.snapshot(applicationContext, "after generation"))

                            withContext(Dispatchers.Main) {
                                userInputEt.isEnabled = true
                                userActionFab.isEnabled = true
                                messages.add(Message(UUID.randomUUID().toString(), summary, false))
                                messageAdapter.notifyItemInserted(messages.size - 1)
                            }
                        }.collect { token ->
                            if (firstTokenNs < 0) firstTokenNs = System.nanoTime()
                            tokenCount++
                            withContext(Dispatchers.Main) {
                                val messageCount = messages.size
                                check(messageCount > 0 && !messages[messageCount - 1].isUser)

                                messages.removeAt(messageCount - 1).copy(
                                    content = lastAssistantMsg.append(token).toString()
                                ).let { messages.add(it) }

                                messageAdapter.notifyItemChanged(messages.size - 1)
                            }
                        }
                }
            }
        }
    }

    /**
     * PHASE 0: standardized pp/tg benchmark, triggered by long-pressing the
     * FAB once a model is loaded.
     *
     * Upstream flags this (see the @Deprecated note) as not fully
     * representative of real chat UX -- which is exactly why
     * handleUserInput() *also* times a real prompt end-to-end. Use both:
     * this one is comparable across devices/models/published llama.cpp
     * numbers, the other is what a student actually feels while waiting.
     *
     * Each of the [BENCH_REPETITION] repetitions logs its own pp/tg speed
     * via LOGi in ai_chat.cpp -- watch logcat during the run (filter tag
     * "InferenceEngineImpl" or "ai-chat") for a declining trend across
     * repetitions. That decline is the practical signature of thermal
     * throttling, and it's the only signal available on devices below API
     * 29 where PowerManager's formal thermal status doesn't exist.
     */
    @Deprecated("Upstream note: doesn't fully reflect real chat-UX performance -- kept as a standardized, cross-device-comparable number. See handleUserInput() for real end-to-end timing.")
    private suspend fun runBenchmark() =
        withContext(Dispatchers.Default) {
            Log.i(TAG, "PHASE0 starting benchmark for $currentModelName")
            Log.i(TAG, "PHASE0 " + DeviceTelemetry.snapshot(applicationContext, "before benchmark"))
            withContext(Dispatchers.Main) {
                userInputEt.hint = "Running benchmark..."
            }
            engine.bench(
                pp = BENCH_PROMPT_PROCESSING_TOKENS,
                tg = BENCH_TOKEN_GENERATION_TOKENS,
                pl = BENCH_SEQUENCE,
                nr = BENCH_REPETITION
            ).let { result ->
                val postBenchSnapshot = DeviceTelemetry.snapshot(applicationContext, "after benchmark")
                Log.i(TAG, "PHASE0 $postBenchSnapshot")
                val annotated = "$result\n$postBenchSnapshot"
                messages.add(Message(UUID.randomUUID().toString(), annotated, false))
                withContext(Dispatchers.Main) {
                    userInputEt.hint = "Type and send a message!"
                    // NB: this is a newly-appended item, not an update to the
                    // last existing one -- notifyItemInserted is correct here
                    // (the original dead code used notifyItemChanged, which
                    // happened to never run since nothing called this fn).
                    messageAdapter.notifyItemInserted(messages.size - 1)
                }
            }
        }

    /**
     * Create the `models` directory if not exist.
     */
    private fun ensureModelsDirectory() =
        File(filesDir, DIRECTORY_MODELS).also {
            if (it.exists() && !it.isDirectory) { it.delete() }
            if (!it.exists()) { it.mkdir() }
        }

    override fun onStop() {
        generationJob?.cancel()
        super.onStop()
    }

    override fun onDestroy() {
        engine.destroy()
        super.onDestroy()
    }

    companion object {
        private val TAG = MainActivity::class.java.simpleName

        private const val DIRECTORY_MODELS = "models"
        private const val FILE_EXTENSION_GGUF = ".gguf"

        private const val BENCH_PROMPT_PROCESSING_TOKENS = 512
        private const val BENCH_TOKEN_GENERATION_TOKENS = 128
        private const val BENCH_SEQUENCE = 1
        private const val BENCH_REPETITION = 3
    }
}

fun GgufMetadata.filename() = when {
    basic.name != null -> {
        basic.name?.let { name ->
            basic.sizeLabel?.let { size ->
                "$name-$size"
            } ?: name
        }
    }
    architecture?.architecture != null -> {
        architecture?.architecture?.let { arch ->
            basic.uuid?.let { uuid ->
                "$arch-$uuid"
            } ?: "$arch-${System.currentTimeMillis()}"
        }
    }
    else -> {
        "model-${System.currentTimeMillis().toHexString()}"
    }
}
