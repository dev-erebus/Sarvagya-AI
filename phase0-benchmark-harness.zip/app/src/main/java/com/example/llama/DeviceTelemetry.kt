package com.example.llama

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import java.io.File

/**
 * Phase 0 telemetry: the numbers that actually answer "does this run
 * acceptably on a 4GB-RAM device". Deliberately has zero dependency on the
 * inference engine or JNI layer -- it only reads OS/process state, so it
 * can't itself be the thing that's wrong if a number looks off.
 */
object DeviceTelemetry {

    /**
     * Resident set size of this process, in MB. This includes mmap'd model
     * weights, unlike [Debug.getNativeHeapAllocatedSize] which can under-count
     * them depending on how ggml maps the file into memory -- RSS is the more
     * trustworthy "how much physical RAM is this app actually holding" number.
     */
    fun residentSetSizeMb(): Double = try {
        var result = -1.0
        File("/proc/self/status").forEachLine { line ->
            if (line.startsWith("VmRSS:")) {
                val kb = line.removePrefix("VmRSS:").trim().removeSuffix("kB").trim().toLong()
                result = kb / 1024.0
            }
        }
        result
    } catch (e: Exception) {
        -1.0
    }

    /**
     * Native heap allocated, in MB -- narrower than RSS (see above). Kept
     * alongside it because a large gap between the two is itself informative:
     * it suggests most memory is mmap'd weights rather than heap allocations.
     */
    fun nativeHeapAllocatedMb(): Double =
        Debug.getNativeHeapAllocatedSize() / 1024.0 / 1024.0

    /**
     * Total and currently-available system RAM (MB), plus whether Android
     * itself considers this device to be under memory pressure right now.
     */
    fun systemMemory(context: Context): Triple<Double, Double, Boolean> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return Triple(
            info.totalMem / 1024.0 / 1024.0,
            info.availMem / 1024.0 / 1024.0,
            info.lowMemory
        )
    }

    /**
     * Thermal throttling status. Only available on API 29+ (Android 10);
     * below that there's no OS-level signal to read. On older devices the
     * honest substitute is watching whether tokens/sec *declines* across
     * repeated bench runs in logcat -- that's the real-world symptom
     * regardless of whether the OS exposes a formal status for it.
     */
    fun thermalStatusLabel(context: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "unavailable (API ${Build.VERSION.SDK_INT} < 29) -- " +
                    "watch for t/s decline across bench repetitions in logcat instead"
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "none"
            PowerManager.THERMAL_STATUS_LIGHT -> "light"
            PowerManager.THERMAL_STATUS_MODERATE -> "moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown"
            else -> "unknown"
        }
    }

    /**
     * One-line device identity so numbers reported back are attributable to
     * a specific chipset/RAM class instead of just "a phone".
     */
    fun deviceSummary(context: Context): String {
        val (totalMb, _, _) = systemMemory(context)
        val cores = Runtime.getRuntime().availableProcessors()
        return "${Build.MANUFACTURER} ${Build.MODEL} | ${Build.HARDWARE} | " +
                "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | " +
                "$cores cores | ~${"%.0f".format(totalMb)}MB total RAM"
    }

    /**
     * A full snapshot, formatted for both logcat and on-screen display.
     * Phase 0 testing may happen at a school with just a phone and no
     * attached laptop, so these numbers need to be readable on-device, not
     * only in logcat.
     */
    fun snapshot(context: Context, label: String): String {
        val rss = residentSetSizeMb()
        val nativeHeap = nativeHeapAllocatedMb()
        val (totalMb, availMb, low) = systemMemory(context)
        val thermal = thermalStatusLabel(context)
        return buildString {
            appendLine("[$label]")
            appendLine("RSS: ${"%.0f".format(rss)}MB  |  native heap: ${"%.0f".format(nativeHeap)}MB")
            appendLine(
                "System free: ${"%.0f".format(availMb)}MB / ${"%.0f".format(totalMb)}MB" +
                        if (low) "  (LOW MEMORY)" else ""
            )
            append("Thermal: $thermal")
        }
    }
}
