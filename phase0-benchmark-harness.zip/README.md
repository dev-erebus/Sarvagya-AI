# Phase 0 — On-Device Inference Feasibility Harness

**Purpose:** answer one question with real numbers — does a quantized chat model actually run acceptably on a 4GB-RAM Android device? Nothing from the master specification gets built on top of this until that's answered.

This is throwaway. It is not the app's architecture, not the final UI, not the final model. It exists to fail fast if the core premise doesn't hold, before any dashboard/planner/test-generator work happens.

## What this actually is

The native inference layer is llama.cpp's own official Android reference implementation (`examples/llama.android` in the [llama.cpp repo](https://github.com/ggml-org/llama.cpp), built with Arm), not a bridge written from scratch. That was a deliberate choice: it already does hardware-aware CPU backend selection, correct current-API model loading/generation, and even ships a standardized pp/tg benchmark — all of which would otherwise be new, unverified JNI code. Writing a parallel bridge from scratch would have meant more custom code to get wrong, for no real benefit.

What was changed from the upstream example, and why:

| Change | File(s) | Why |
|---|---|---|
| `minSdk` 33 → 24 | `app/build.gradle.kts`, `lib/build.gradle.kts` | Upstream targets modern chips to showcase new CPU features. That's not our audience — see "Open question" below. |
| Vendoring via CMake `FetchContent` (pinned commit) instead of a relative-path `add_subdirectory` | `lib/src/main/cpp/CMakeLists.txt` | The relative path only worked because the upstream example lives inside the llama.cpp monorepo. We extracted it to stand alone. |
| New `DeviceTelemetry.kt` | `app/src/main/java/com/example/llama/` | Memory (RSS + native heap), system free RAM, and thermal status — the numbers Phase 0 actually needs, read directly from the OS, with zero dependency on the inference engine itself. |
| Wired up the real chat-generation path and the existing (previously unused) `bench()` function with timing + telemetry snapshots | `MainActivity.kt` | Get both a standardized, cross-device-comparable number (pp/tg bench) *and* a real end-to-end number (actual prompt → actual reply, timed) — the upstream code itself flags the bench alone as not fully representative of chat UX. |

No changes were made to `ai_chat.cpp` or any other native inference code — only build config and pure-Kotlin additions. That was deliberate: it's the highest-value, lowest-risk way to add what Phase 0 needs without touching verified upstream logic.

## Honesty about what I could and couldn't verify here

I don't have an Android SDK/NDK, an emulator, or a physical device in my sandbox, and Google's Maven/NDK download servers aren't reachable from it — so I could not actually build or run this app myself. Concretely, here's what I *did* verify, and what still needs your machine:

- ✅ Cloned the real, current llama.cpp source and read the actual API rather than relying on possibly-stale training knowledge.
- ✅ The modified `CMakeLists.txt` successfully configures end-to-end on a host Linux machine (validates syntax, confirms the pinned commit is fetchable, confirms llama.cpp's own build system accepts our options).
- ✅ A bounded host build of the core `llama` library (the part shared with the Android build, everything except the Android-specific JNI glue) got roughly two-thirds through compiling with zero errors before I cut it off to stay within a reasonable amount of time — a reasonable proxy for "the pinned commit isn't broken," not a full guarantee.
- ❌ Not verified: actual Android cross-compilation, the Kotlin code (no Kotlin compiler available in my sandbox either), or anything that only shows up when it actually runs on a device.

Translation: this is carefully reasoned and partially validated, not proven. The first real build in Android Studio is likely to surface at least something small. That's normal — send me the error and we'll fix it, same as any real development loop.

## One open question before you build

**`minSdk = 24` (Android 7.0, 2016) is a reasoned guess, not a verified number.** Rural/budget Indian devices skew toward older, hand-me-down hardware, so I moved it well below upstream's `33` — but I don't have precise data on the actual Android-version distribution in this specific population. If you have a better sense of the real floor (or want to just ship it and see what install data says), change the one line in `app/build.gradle.kts` and `lib/build.gradle.kts`.

## Setup

1. **Android Studio** (recent — this project uses AGP 8.13.2, Kotlin 2.3.0, compileSdk 36). Open the `phase0-harness/` folder directly (not a parent folder).
2. **First sync** will download Gradle, dependencies, and — if not already installed — NDK `29.0.13113456` automatically. This needs a normal internet connection on your machine; give it a few minutes the first time.
3. **Get a GGUF model** matching the master spec's default tier (~2B, Q4_K_M) — e.g. search Hugging Face for `Gemma-2-2b-it-GGUF` or `Qwen2.5-1.5B-Instruct-GGUF` and grab the `Q4_K_M` file. Any instruct-tuned GGUF in that size class works for this test; it doesn't need to be the final model.
4. **Get it onto the test device** — no adb needed. The app's FAB button opens a system file picker (works from Downloads, a USB drive, wherever); it copies the file into app-private storage on first pick.

## Running it

- **Real device strongly preferred over an emulator** for this phase — emulator CPU performance doesn't reflect real ARM silicon, which defeats the point of Phase 0. If you only have an emulator available, it's fine for confirming the app doesn't crash, just don't trust its tokens/sec numbers.
- If you do use an emulator: AVD Manager → your device → Edit → set RAM to ~4096MB to at least match the target memory ceiling.
- **Tap** the FAB to pick a GGUF file → wait for load (a message with load time + memory snapshot appears in the chat log itself, not just logcat, so this is readable even without a laptop attached).
- **Type a message and send** → this exercises the real chat path. When the reply finishes, a summary message appears with time-to-first-token, decode tokens/sec, and a post-generation memory/thermal snapshot.
- **Long-press the FAB** (once a model is loaded) → runs the standardized pp512/tg128 benchmark, 3 repetitions. Watch **Logcat filtered to `InferenceEngineImpl` or `ai-chat`** during this run — each repetition logs its own speed, and a declining trend across the three is the practical signature of thermal throttling (this matters most on devices below Android 10/API 29, where there's no formal OS thermal-status API to read instead).

## What to report back

For each device you test on, paste (or screenshot) the on-screen telemetry messages from the chat log — they contain everything: device summary, load time, real-chat timing, bench results, and memory snapshots. If something crashes or fails to build, the Logcat/Build-output error text is the most useful thing to send.

## After this

Once we have real numbers from at least one genuinely low-end (4GB RAM class) device, we'll know whether the master spec's model-tier assumption holds as-is, needs a smaller default, or needs the graceful-fallback behavior (Section 8 of the master spec) built in from the start rather than as an afterthought. That decides how Phase 1 starts.
