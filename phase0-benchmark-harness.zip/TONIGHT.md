# Tonight's course of action

Read this after `MASTER_PROMPT.md`, `CLAUDE.md`, and `master_specification.md`
— those give full project context. This file is tonight's specific,
time-boxed focus on top of that context, not a replacement for it.

## Tonight's actual target

Not a finished app. Not a Play Store submission — that's structurally
impossible before a 14-day closed-testing clock even starts (see
`MASTER_PROMPT.md`, Section 8). Tonight's real target: close M1, push as
far into M2 as the session allows, and if a stable build exists by the end
of the session, package it for closed-testing submission even though most
features aren't built yet — starting that clock early is more valuable
right now than any single feature.

## Order of operations, tonight specifically

1. **M1 first, no exceptions.** Confirm a device is connected (via
   `adb devices`) before doing anything else. If none is connected, that is
   the literal first blocker to resolve — stop and say so rather than
   working around it with an emulator by default.
2. Download the model from `REFERENCES.md` (already verified — no need to
   re-search for it) and load it in `phase0-harness`. Send it a real
   message. A coherent reply confirms the chat template survived
   conversion; the model only continuing the input text instead of
   answering means it did not — check this explicitly, don't assume.
3. Record the real M1 numbers (load time, RSS, pp/tg bench, real chat
   tokens/sec) and make the model-tier call from evidence.
4. Once M1 closes, move to M2 and stay there. Do not get pulled into
   Dashboard/Planner/UI work tonight even if it feels like faster visible
   progress — the phased order in `master_specification.md` exists on
   purpose, hardest and least-reversible part first.
5. **If time is genuinely running out before M2 finishes:** stop at the
   most stable checkpoint, not mid-refactor. A working chat screen that
   does less is a better place to stop than a broken one that attempts
   more.
6. **If a stable, crash-free build exists at any point tonight** — even
   just offline chat, nothing else — flag this immediately rather than
   continuing feature work first. That's the cue to package a signed build
   and get it into a closed-testing track (Play Console: Test and release →
   Testing → Closed testing). Starting the 14-day clock tonight is worth
   more than one more feature.

## Budget discipline tonight

- Default to Sonnet for repetitive or mechanical work. Reserve Fable 5 for
  inference-wiring and actual debugging.
- Checkpoint with the user after each concrete step, not only at the very
  end — long silent stretches are how a usage window gets spent on work
  that turns out to need redoing.

## Report back at the end of the session

- What is actually, concretely working right now (precise, not optimistic)
- The real M1 numbers
- Whether a build reached closed-testing-ready state, and if not, what's
  blocking it
- The single next action for tomorrow
